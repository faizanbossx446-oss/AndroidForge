APP_ABI := arm64-v8a 
APP_PLATFORM := android-18  # ← Must match minSdkVersion 16
APP_STL := c++_static
APP_OPTIM := release
APP_THIN_ARCHIVE := true
APP_PIE := true
APP_CPPFLAGS += -lrt