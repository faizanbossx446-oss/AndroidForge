# THE VG PRIME X — Android UI Demo

यह Kotlin आधारित Android Studio starter project है। यह केवल एक local visual/UI simulation है।

## क्या काम करता है
- Dashboard और premium blue/purple glass-inspired styling
- In-app control window: minimize, expand, hide/restore, close
- Feature demo switches और Edit dialogs
- Demo intensity sliders
- Location preview के लिए marker-count/opacity sliders और color buttons
- Window size/transparency demo sliders
- About dialog

## सुरक्षा और सीमाएँ
- यह Free Fire, Free Fire MAX या किसी अन्य गेम से connect नहीं होता।
- इसमें aim assist, headshot, Magic Bullet, ESP/player location, speed modification, ghosting, anti-cheat bypass या game memory/process modification नहीं है।
- Root permission request नहीं की जाती; Root status केवल explanatory demo text है।
- स्क्रीन रिकॉर्डिंग से UI छिपाने/stealth behavior का कोई फीचर नहीं है।

## इस अपडेट में Build Error Fix
- `compileDebugJavaWithJavac` पहले JVM target `1.8` पर था जबकि Kotlin `17` पर था।
- `app/build.gradle.kts` में Java source/target और Kotlin `jvmTarget` तीनों को `17` पर align किया गया है।
- यह बदलाव तुम्हारे भेजे हुए `Inconsistent JVM-target compatibility` error को address करता है।
- इस वातावरण में Android SDK/Gradle उपलब्ध नहीं था, इसलिए अंतिम APK build को यहाँ run करके verify नहीं किया गया है।

## Build APK
1. Android Studio (Giraffe या नया) इंस्टॉल करें।
2. `THE_VG_PRIME_X` फोल्डर को Open करें।
3. Gradle sync पूरा होने दें। इंटरनेट पहली बार Gradle/Android Gradle Plugin डाउनलोड करने के लिए चाहिए।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. Debug APK सामान्यतः `app/build/outputs/apk/debug/app-debug.apk` में बनेगा।

## Technical details
- Package: `com.vg.primex`
- App label: `THE VG PRIME X`
- Language: Kotlin
- minSdk: 23
- compileSdk/targetSdk: 35
- UI: Android Views (no third-party UI dependency)

## Note about supplied reference images
आपके दिए गए पाँच reference images `app/src/main/assets/` में रखे गए हैं। Main screen पर crown VG image उपयोग होती है। बाकी images reference assets हैं।
