plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.vg.primex"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.vg.primex"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.1"
    }

    // Keep Java and Kotlin bytecode targets aligned.
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
