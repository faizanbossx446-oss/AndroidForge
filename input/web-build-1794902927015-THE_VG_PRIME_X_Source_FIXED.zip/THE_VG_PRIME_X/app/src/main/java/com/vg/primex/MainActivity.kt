package com.vg.primex

import android.app.Activity
import android.app.AlertDialog
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 10, 24)
    private val panel = Color.rgb(20, 27, 54)
    private val cyan = Color.rgb(89, 225, 255)
    private val purple = Color.rgb(164, 117, 255)
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var windowCard: LinearLayout
    private lateinit var windowBody: LinearLayout
    private lateinit var restoreButton: Button
    private var minimized = false
    private var hidden = false
    private val states = mutableMapOf<String, Boolean>()
    private val values = mutableMapOf<String, Int>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        buildScreen()
    }

    private fun buildScreen() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(16))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(bg, Color.rgb(18, 18, 48), Color.rgb(8, 20, 39)))
        }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        val logo = ImageView(this).apply {
            try { setImageBitmap(BitmapFactory.decodeStream(assets.open("vg_crown_logo.jpg"))) } catch (_: Exception) {}
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.WHITE, 18)
            clipToOutline = true
        }
        top.addView(logo, LinearLayout.LayoutParams(dp(58), dp(58)))
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        titleBox.addView(label("THE VG PRIME X", 19, Color.WHITE, true))
        titleBox.addView(label("PREMIUM INTERFACE  •  DEMO BUILD", 9, cyan, true))
        top.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        val status = label("DEMO", 10, cyan, true).apply { background = rounded(Color.rgb(26, 54, 77), 30); setPadding(dp(10), dp(7), dp(10), dp(7)) }
        top.addView(status)
        content.addView(top)
        content.addView(space(16))

        val hero = card()
        val infinity = label("∞", 54, cyan, true).apply { gravity = Gravity.CENTER; setShadowLayer(18f, 0f, 0f, purple) }
        hero.addView(infinity, LinearLayout.LayoutParams(-1, dp(76)))
        hero.addView(label("WELCOME TO VG PRIME X", 17, Color.WHITE, true).apply { gravity = Gravity.CENTER })
        hero.addView(label("Liquid Glass Gaming UI • Interactive visual simulation", 11, Color.LTGRAY, false).apply { gravity = Gravity.CENTER; setPadding(0, dp(5), 0, dp(8)) })
        val rootStatus = label("ROOT STATUS  •  SIMULATED / NOT CHECKED", 10, Color.rgb(255, 211, 125), true).apply { gravity = Gravity.CENTER; setPadding(dp(8), dp(9), dp(8), dp(9)); background = rounded(Color.rgb(62, 48, 31), 12) }
        hero.addView(rootStatus)
        content.addView(hero)
        content.addView(space(14))

        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        restoreButton = button("RESTORE WINDOW", cyan) { showWindow() }
        actionRow.addView(restoreButton, LinearLayout.LayoutParams(0, dp(46), 1f))
        val about = button("ABOUT", purple) { showAbout() }
        val aboutLp = LinearLayout.LayoutParams(0, dp(46), 0.55f).apply { leftMargin = dp(8) }
        actionRow.addView(about, aboutLp)
        content.addView(actionRow)
        content.addView(space(14))

        windowCard = card()
        val windowHeader = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        windowHeader.addView(label("VG CONTROL WINDOW", 14, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        windowHeader.addView(smallAction("−") { minimizeWindow() })
        windowHeader.addView(smallAction("□") { expandWindow() })
        windowHeader.addView(smallAction("⌁") { hideWindow() })
        windowHeader.addView(smallAction("×") { closeWindow() })
        windowCard.addView(windowHeader)
        windowCard.addView(space(10))
        windowBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        windowCard.addView(windowBody)
        content.addView(windowCard)
        addSectionTitle("FEATURE CONTROLS  •  VISUAL DEMO")
        val featureList = listOf(
            "Magic Bullet" to "Visual-only control; no game interaction",
            "Aim Silent" to "Visual-only control; no aiming function",
            "Body Headshot" to "Offline UI simulation only",
            "ESP Line" to "Decorative line preview only",
            "Ghost Mode" to "Panel appearance preview only",
            "Speed Boost" to "Device-independent demo slider"
        )
        featureList.forEach { (name, desc) -> addFeature(name, desc) }
        addSectionTitle("LOCATION WIDGET CUSTOMIZATION")
        addLocationControls()
        addSectionTitle("WINDOW APPEARANCE")
        addWindowControls()
        content.addView(space(12))
        content.addView(label("VG • EDUCATIONAL UI DEMO • NO GAME CONNECTION", 9, Color.GRAY, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(8)) })
        refreshWindow()
    }

    private fun addFeature(name: String, desc: String) {
        val c = card()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val textBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        textBox.addView(label(name, 14, Color.WHITE, true))
        textBox.addView(label(desc, 10, Color.LTGRAY, false).apply { setPadding(0, dp(3), 0, 0) })
        row.addView(textBox, LinearLayout.LayoutParams(0, -2, 1f))
        val toggle = Switch(this).apply {
            buttonTintList = android.content.res.ColorStateList.valueOf(cyan)
            isChecked = false
            setOnCheckedChangeListener { _, checked -> states[name] = checked; Toast.makeText(this@MainActivity, "$name: ${if (checked) "Demo ON" else "Demo OFF"}", Toast.LENGTH_SHORT).show() }
        }
        row.addView(toggle)
        val edit = button("EDIT", purple) { editFeature(name) }
        val editLp = LinearLayout.LayoutParams(dp(66), dp(38)).apply { leftMargin = dp(8) }
        row.addView(edit, editLp)
        c.addView(row)
        content.addView(c)
        content.addView(space(8))
    }

    private fun editFeature(name: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), dp(4)) }
        val valueText = label("Demo intensity: ${values[name] ?: 50}%", 13, Color.WHITE, true)
        box.addView(valueText)
        val seek = SeekBar(this).apply { max = 100; progress = values[name] ?: 50; progressTintList = android.content.res.ColorStateList.valueOf(cyan); thumbTintList = android.content.res.ColorStateList.valueOf(purple) }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { valueText.text = "Demo intensity: $p%"; values[name] = p }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(seek)
        box.addView(label("This setting changes only the demonstration interface. It does not affect Free Fire or any other game.", 10, Color.LTGRAY, false))
        AlertDialog.Builder(this).setTitle("Edit • $name").setView(box).setPositiveButton("SAVE", null).setNegativeButton("CANCEL", null).show()
    }

    private fun addLocationControls() {
        val c = card()
        c.addView(label("LOCATION PREVIEW", 13, Color.WHITE, true))
        c.addView(label("Demo markers only — no player or game location is accessed.", 10, Color.LTGRAY, false).apply { setPadding(0, dp(4), 0, dp(8)) })
        addSlider(c, "Visible demo markers", 1, 10, 3)
        addSlider(c, "Widget opacity", 10, 100, 85)
        val colors = listOf("CYAN" to cyan, "PURPLE" to purple, "WHITE" to Color.WHITE, "PINK" to Color.rgb(255, 105, 190))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        colors.forEach { (name, color) ->
            val b = button(name, color) { Toast.makeText(this, "$name preview selected", Toast.LENGTH_SHORT).show() }
            row.addView(b, LinearLayout.LayoutParams(0, dp(38), 1f).apply { rightMargin = dp(4) })
        }
        c.addView(row)
        content.addView(c)
        content.addView(space(8))
    }

    private fun addWindowControls() {
        val c = card()
        addSlider(c, "Window size", 70, 130, 100)
        addSlider(c, "Window transparency", 20, 100, 95)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("MINIMIZE", cyan) { minimizeWindow() }, LinearLayout.LayoutParams(0, dp(40), 1f))
        row.addView(button("EXPAND", purple) { expandWindow() }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { leftMargin = dp(6) })
        content.addView(c)
        content.addView(space(8))
        content.addView(row)
    }

    private fun addSlider(parent: LinearLayout, title: String, min: Int, max: Int, initial: Int) {
        val t = label("$title: $initial", 11, Color.WHITE, true)
        parent.addView(t)
        val seek = SeekBar(this).apply { this.max = max - min; progress = initial - min; progressTintList = android.content.res.ColorStateList.valueOf(cyan); thumbTintList = android.content.res.ColorStateList.valueOf(purple) }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { t.text = "$title: ${p + min}" }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(seek)
    }

    private fun addSectionTitle(text: String) {
        content.addView(label(text, 11, cyan, true).apply { setPadding(dp(3), dp(17), 0, dp(8)) })
    }

    private fun refreshWindow() {
        windowBody.removeAllViews()
        if (minimized) {
            windowBody.addView(label("WINDOW MINIMIZED • Press □ to expand", 11, Color.LTGRAY, false))
        } else {
            windowBody.addView(label("CONTROL CENTER", 12, cyan, true))
            windowBody.addView(label("All switches and edit controls in this build are visual simulations.", 10, Color.LTGRAY, false).apply { setPadding(0, dp(5), 0, dp(0)) })
        }
    }
    private fun minimizeWindow() { minimized = true; refreshWindow() }
    private fun expandWindow() { minimized = false; hidden = false; windowCard.visibility = View.VISIBLE; refreshWindow() }
    private fun hideWindow() { hidden = true; windowCard.visibility = View.GONE; restoreButton.visibility = View.VISIBLE }
    private fun showWindow() { hidden = false; minimized = false; windowCard.visibility = View.VISIBLE; restoreButton.visibility = View.VISIBLE; refreshWindow() }
    private fun closeWindow() { windowCard.visibility = View.GONE; restoreButton.visibility = View.VISIBLE; Toast.makeText(this, "Demo window closed", Toast.LENGTH_SHORT).show() }
    private fun showAbout() { AlertDialog.Builder(this).setTitle("THE VG PRIME X").setMessage("Premium Liquid Glass UI demonstration. No root access is requested. No game process, memory, network, aiming, ESP, or anti-cheat is accessed or modified.").setPositiveButton("OK", null).show() }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(13), dp(14), dp(13))
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(29, 42, 78), Color.rgb(23, 28, 59))).apply {
            cornerRadius = dp(20).toFloat(); setStroke(dp(1), Color.argb(90, 125, 190, 255))
        }
        elevation = dp(3).toFloat()
    }
    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD)
    }
    private fun button(text: String, accent: Int, action: () -> Unit): Button = Button(this).apply {
        this.text = text; textSize = 10f; setTextColor(if (accent == Color.WHITE) Color.BLACK else Color.WHITE); isAllCaps = false
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(accent, blend(accent, purple))).apply { cornerRadius = dp(13).toFloat() }
        setOnClickListener { action() }
    }
    private fun smallAction(text: String, action: () -> Unit): TextView = label(text, 19, Color.WHITE, true).apply {
        gravity = Gravity.CENTER; background = rounded(Color.rgb(48, 59, 100), 10); setOnClickListener { action() }
        val p = dp(34); layoutParams = LinearLayout.LayoutParams(p, p).apply { leftMargin = dp(5) }
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun space(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun blend(a: Int, b: Int): Int = Color.rgb((Color.red(a) + Color.red(b)) / 2, (Color.green(a) + Color.green(b)) / 2, (Color.blue(a) + Color.blue(b)) / 2)
}
